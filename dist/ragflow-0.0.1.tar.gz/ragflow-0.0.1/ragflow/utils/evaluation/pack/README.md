DO NOT DELETE
This readme file is needed to install from pyproject.toml.